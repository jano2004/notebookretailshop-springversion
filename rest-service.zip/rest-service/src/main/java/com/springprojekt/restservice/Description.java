package com.springprojekt.restservice;

public class Description {
	//Notebookshop Springedition
}

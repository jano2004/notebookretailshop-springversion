package com.springprojekt.restservice;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller 
@RequestMapping("/notebook")
public class UIController {
	
	@GetMapping
	public String showUI(Model model) {
		model.addAttribute("color", "");
		model.addAttribute("layout", "");
		model.addAttribute("monitorSizeInInches", "");
		
		model.addAttribute("ram", "");
		model.addAttribute("cpu", "");
		model.addAttribute("gpu", "");
		model.addAttribute("mainboard", "");
		model.addAttribute("psu", "");
		model.addAttribute("drives", "");
		
		return "ui";
	}
	
	@PostMapping("/processInput")
	public String processInput(String color, String layout, String monitorSizeInInches,
			String ram, String cpu, String gpu, String mainboard, String psu, String drives) {
			Notebook notebook = null;
			PC pc = null;
		if(color != "" && layout != "" && monitorSizeInInches != "") {	
			notebook = new Notebook(notebook.getCount()+1, color, layout, Integer.valueOf(monitorSizeInInches), "1");
		}
		else {
			pc= new PC(pc.getCount()+1, ram, cpu, gpu, mainboard, psu, drives, "1");
		}
		return "redirect:/";
	}
}

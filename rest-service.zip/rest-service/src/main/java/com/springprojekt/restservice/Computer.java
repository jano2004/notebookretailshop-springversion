package com.springprojekt.restservice;

abstract class Computer {
	protected int id;
	protected String macAddress;
}
